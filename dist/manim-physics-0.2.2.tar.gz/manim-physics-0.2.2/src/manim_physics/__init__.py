__version__ = "0.2.2"

from .electromagnetism import *
from .pendulum import *
from .rigid_mechanics import *
from .wave import *
